#include "game.h"
#include<iostream>
using namespace std;

void game::draw_platform()
{
	for (int i = 0; i < HEIGHT; i++)
	{
		for (int j = 0; j < WIDTH; j++)
		{
			if (platform[i][j] == 1)
			{
				cout << "*";
			}
			else
			{
				cout << " ";
			}
		}
		cout << endl;
	}
}

void game::next_generation()
{
	int temporary_platform[HEIGHT][WIDTH];
	int neighbours;

	for (int i = 0; i < HEIGHT; i++)
	{
		for (int j = 0; j < WIDTH; j++)
		{
			if (i == 0 || j == 0 || i == HEIGHT || j == WIDTH)
			{
				temporary_platform[i][j] = 0;
			}

			else
			{
				neighbours = platform[i - 1][j - 1] + platform[i - 1][j] + platform[i - 1][j + 1] + platform[i][j - 1] +
					platform[i][j + 1] + platform[i + 1][j - 1] + platform[i + 1][j] + platform[i + 1][j + 1];

				if (platform[i][j] == 1)
				{
					if (neighbours < 2 || neighbours >3)
					{
						temporary_platform[i][j] = 0;
					}
					else
					{
						temporary_platform[i][j] = 1;
					}
				}

				else
				{
					if (neighbours == 3)
					{
						temporary_platform[i][j] = 1;
					}
					else
					{
						temporary_platform[i][j] = 0;
					}
				}
			}
		}
	}

	copy(temporary_platform, platform);
}

void game::copy(int platform1[HEIGHT][WIDTH], int platform2[HEIGHT][WIDTH])
{
	for (int i = 0; i < HEIGHT; i++)
	{
		for (int j = 0; j < WIDTH; j++)
		{
			platform2[i][j] = platform1[i][j];
		}
	}
}
