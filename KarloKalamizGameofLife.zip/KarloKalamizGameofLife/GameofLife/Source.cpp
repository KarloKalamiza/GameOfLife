#include<iostream>
#include"game.h"

using namespace std;

int main() {
	bool repeat;

	game g;

	do
	{
		g.draw_platform();
		g.next_generation();

		cout << "Dalje(1/0): ";
		cin >> repeat;
	} while (repeat);


	return 0;
}